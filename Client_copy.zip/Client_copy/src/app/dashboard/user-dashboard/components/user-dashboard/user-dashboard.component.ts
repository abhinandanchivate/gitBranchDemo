import { Component, OnInit } from '@angular/core';
import { Profile } from 'src/app/profile/models/profile';
import { ProfileService } from 'src/app/profile/services/profile.service';
import { Register } from 'src/app/user/model/register';

@Component({
  selector: 'app-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.css'],
})
export class UserDashboardComponent implements OnInit {
  userDetail: Register = JSON.parse(
    localStorage.getItem('userDetails') || '{}'
  );
  errors: any;
  status: string;
  profile: Profile = {
    bio: '',
    company: '',
    facebook: '',
    gitusername: '',
    instagram: '',
    twitter: '',
    linkedin: '',
    location: '',
    skill: [],
    status: '',
    website: '',
    youtube: '',
    profile: '',
  };
  constructor(private profileService: ProfileService) {}

  ngOnInit(): void {
    this.profileService.getProfile().subscribe(
      (res) => console.log(JSON.stringify(res)),
      (err) => {
        console.log(JSON.stringify(err));
        this.errors = err.error;
      }
    );
  }
}
