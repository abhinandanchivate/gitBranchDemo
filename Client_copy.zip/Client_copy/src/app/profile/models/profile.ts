export interface Profile {
  profile: string;
  status: string;
  company: string;
  website: string;
  location: string;
  skill: string[];
  gitusername: string;
  bio: string;
  twitter: string;
  facebook: string;
  linkedin: string;
  youtube: string;
  instagram: string;
}
